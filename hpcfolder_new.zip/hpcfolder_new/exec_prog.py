"""

Do not change anything in this code except the places where 'change this' is written.
Written by: Kunal Jani
Student ID: 201601444

"""

import os
thread_range=[1,2,3,4,5,6,7,8] #Change this
prob_size=[16,32,64,128,256] #Change this
j=0
no_of_runs=10  #Change this
os.system('rm combined_logs.csv')
os.system('gcc write_title.c -o write_title')
os.system('./write_title')
os.system('gcc serial_code.c -fopenmp -o serial_code')
os.system('gcc parallel_code.c -fopenmp -o parallel_code')
for i in range(no_of_runs):
    print('Run '+str(i)+':\n\n')
    for i in range(len(prob_size)):
        print('Serial run:\n\n')
        os.system('./serial_code '+str(prob_size[i])+' '+str(thread_range[j]))
        print('Parallel run:\n\n')
        for j in range(len(thread_range)):
            os.system('./parallel_code '+str(prob_size[i])+' '+str(thread_range[j]))
