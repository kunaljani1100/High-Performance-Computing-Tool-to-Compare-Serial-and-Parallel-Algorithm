/**********************************************************
Serial K Means Clustering Algorithm Written in C
Kunal Jani, Dhirubhai Ambani Institute of Information and Communication Technology, Gandhinagar
Student ID: 201601444
************************************************************/

#include<stdio.h>
#include<omp.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#define CLK CLOCK_MONOTONIC
struct timespec diff(struct timespec start, struct timespec end){
	struct timespec temp;
	if((end.tv_nsec-start.tv_nsec)<0){
		temp.tv_sec = end.tv_sec-start.tv_sec-1;
		temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
	}
	else{
		temp.tv_sec = end.tv_sec-start.tv_sec;
		temp.tv_nsec = end.tv_nsec-start.tv_nsec;
	}
	return temp;
}

int main(int argc,char *argv[])
{
struct timespec start_e2e, end_e2e, start_alg, end_alg, e2e, alg;
clock_gettime(CLK, &start_e2e);
if(argc < 3){
		printf( "Usage: %s n p \n", argv[0] );
		return -1;
	}
	
long long int n=(long long int)atoi(argv[1]),no_of_clusters=10;//Total number of points and number of clusters initialized
int p=atoi(argv[2]);

	clock_gettime(CLK, &start_alg);
//---------------------------------------------------------
//--------------------------------------------------------
//Your algorithm will begin here

	int i,j,k;	
	double **a=(double **)malloc(n*sizeof(double *));
	double **b=(double **)malloc(n*sizeof(double *));
	double **r=(double **)malloc(n*sizeof(double *));
	for(i=0;i<n;i++)
	{
		a[i]=(double *)malloc(n*sizeof(double *));	
		b[i]=(double *)malloc(n*sizeof(double *));	
		r[i]=(double *)malloc(n*sizeof(double *));	
		for(j=0;j<n;j++)
		{
			a[i][j]=1;
			b[i][j]=1;
			r[i][j]=1;
		}
	}
	
	for (i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			for(k=0;k<n;k++)
			{	
				r[i][j]=r[i][j]+a[i][k]*b[k][j];
			}
		}
	}
	




//-------------------------------------------------------------
//--------------------------------------------------------------
//------------
//Algorithm will end here
clock_gettime(CLK, &end_alg);
clock_gettime(CLK, &end_e2e);
e2e = diff(start_e2e, end_e2e);
alg = diff(start_alg, end_alg);

#pragma omp critical
{
	FILE *fps;
	fps=fopen("combined_logs.csv","a");
	fprintf(fps,"%lld,0,%ld\n",n,alg.tv_nsec);
	fclose(fps);
}

printf("%lld,%d,%ld,%ld,%ld,%ld\n",n, p, e2e.tv_sec, e2e.tv_nsec, alg.tv_sec, alg.tv_nsec);
	//Write each and every output to a csv file, and read all the csv files from the python script 
	//2dkmeansplot.ipynb in google colab after uploading all the csv files and obtain the plot of the k means 
	//cluster obtained.
/******************
	FILE *fp;
	
	char *filename;
	char clno[2];
	for(i=0;i<no_of_clusters;i++)
	{
		strcpy(filename,"cluster");
		sprintf(clno,"%lld",i);
		strcat(filename,clno);
		strcat(filename,".csv");
		fp=fopen(filename,"w+");
		fprintf(fp,",x,y");
		for(j=0;j<filled_p[i];j++)
		{
		
			fprintf(fp,"\n%lld",j+1);
			fprintf(fp,",%f",clusters2_x[i][j]);
			fprintf(fp,",%f",clusters2_y[i][j]);
		}
		fclose(fp);
	}
	*****************/
	/*
	for(i=0;i<no_of_clusters;i++)
	{
		if(i==0)
		{
			fp=fopen("cluster0.csv","w+");
		}
		if(i==1)
		{
			fp=fopen("cluster1.csv","w+");
		}
		if(i==2)
		{
			fp=fopen("cluster2.csv","w+");
		}
		if(i==3)
		{
			fp=fopen("cluster3.csv","w+");
		}
		if(i==4)
		{
			fp=fopen("cluster4.csv","w+");
		}
		fprintf(fp,",x,y");
		for(j=0;j<filled_p[i];j++)
		{
			fprintf(fp,"\n%lld",j+1);
			fprintf(fp,",%f",clusters2_x[i][j]);
			fprintf(fp,",%f",clusters2_y[i][j]);
		}
		fclose(fp);		
	}
*/

/*
	for(i=0;i<no_of_clusters;i++)
	{
		printf("New cluster:");
		for(j=0;j<filled_p[i];j++)
		{
			printf("%f,%f\n",clusters_x[i][j],clusters_y[i][j]);
		}
	}
*/	
}
