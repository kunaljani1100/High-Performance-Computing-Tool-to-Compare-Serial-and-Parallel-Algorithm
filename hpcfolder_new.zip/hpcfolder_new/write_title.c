/*************************************
Written by Kunal Jani
Student ID: 201601444
Do not modify this code.
**************************************/
#include<stdio.h>
#include<stdlib.h>
int main()
{
	FILE *fp;
	fp=fopen("combined_logs.csv","a");
	fprintf(fp,"Problem Size,Threads,Execution time\n");
	fclose(fp);
}
